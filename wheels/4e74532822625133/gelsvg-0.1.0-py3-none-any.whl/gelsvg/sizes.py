"""Reading marker labels as sizes (§5.14 "Reading a size").

A marker label holds only the text drawn. It reads as a size when it is a
number, optionally followed by a unit; as nothing otherwise. A size written
without a unit takes the unit `core.marker_unit` names, when it names one: a
unit alone, optionally in parentheses (the `kDa` drawn beside a ladder's
numbers).
"""

from __future__ import annotations

import re

UNITS = {"kda": "kDa", "kd": "kDa", "bp": "bp", "kb": "kb", "kbp": "kb", "nt": "nt"}
"""The units a label may name, without regard to case (of ASCII letters
only), and the unit each is."""

WHITE_SPACE = (
    "\t\n\x0b\x0c\r \x85\xa0\u1680"
    "\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a"
    "\u2028\u2029\u202f\u205f\u3000"
)
"""The white space of §5.14: the 25 characters with the Unicode property
White_Space. Not `str.strip()`'s, which takes U+001C–U+001F too, nor any
regular expression engine's `\\s`."""

_UNIT = "kda|kd|kbp|kb|bp|nt"
_SPACE = "[" + re.escape(WHITE_SPACE) + "]"
_SIZE = re.compile(rf"([0-9]{{1,3}}(?:,[0-9]{{3}})+|[0-9]+)(\.[0-9]+)?{_SPACE}*({_UNIT})?", re.IGNORECASE | re.ASCII)
_ALONE = re.compile(rf"({_UNIT})|\(({_UNIT})\)", re.IGNORECASE | re.ASCII)


def read_label(label: str) -> tuple | None:
    """What one label reads as: (number, unit or None), or None for any other
    text."""

    match = _SIZE.fullmatch(label.strip(WHITE_SPACE))
    if not match:
        return None
    number = float(match.group(1).replace(",", "") + (match.group(2) or ""))
    if number <= 0:
        return None
    return number, UNITS[match.group(3).lower()] if match.group(3) else None


def read_unit(marker_unit: str | None) -> str | None:
    """The unit `core.marker_unit` names, or None: absent, or other text
    (`MW`), which is drawn but names no unit."""

    if not isinstance(marker_unit, str):
        return None
    match = _ALONE.fullmatch(marker_unit.strip(WHITE_SPACE))
    return UNITS[(match.group(1) or match.group(2)).lower()] if match else None


def marker_sizes(markers, marker_unit: str | None = None) -> list[dict | None]:
    """The size each of a panel's marker labels reads as, in their order:
    `{"value", "unit"}` (`unit` None when it cannot be determined), or None
    for a label that is no size. `markers` and `marker_unit` as
    `core.markers` and `core.marker_unit` hold them."""

    shared = read_unit(marker_unit)
    out = []
    for m in markers:
        read = read_label(m["label"]) if isinstance(m.get("label"), str) else None
        if read is None:
            out.append(None)
            continue
        number, unit = read
        out.append({"value": int(number) if number.is_integer() else number,
                    "unit": unit if unit is not None else shared})
    return out
