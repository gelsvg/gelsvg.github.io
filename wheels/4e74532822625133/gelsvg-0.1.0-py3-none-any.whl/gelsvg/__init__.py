"""Read and write GelSVG documents (`.gel.svg`)."""

from .container import Container, PanelSlot, read_container
from ._hashes import core_hash, pixel_hash, quant_core_hash, rendered_hash
from .document import Assembly, Document, drawing_of, read, read_sets
from .drawing import aligned_image, aligned_size, default_crop, render, to_channel, to_panel
from .notices import Kind, Notice
from .panel import Panel
from .sizes import marker_sizes
from .sources import SourceError, SourceImage, read_source
from .writer import (Content, Saved, Tool, WriteError, WriteNote, assembly_only, image_element, new_assembly_id,
                     new_panel, replace_element, rewrite_panel, save, set_attributes, sign)

__version__ = "0.1.0"

__all__ = [
    "Assembly", "Container", "Content", "Document", "Kind", "Notice", "Panel", "PanelSlot", "Saved", "Tool",
    "WriteError", "WriteNote", "aligned_image", "aligned_size", "assembly_only", "core_hash", "default_crop",
    "drawing_of", "image_element", "marker_sizes", "new_assembly_id", "new_panel", "pixel_hash", "quant_core_hash", "read",
    "read_container", "read_sets", "render", "rendered_hash", "replace_element",
    "rewrite_panel", "save", "set_attributes", "sign", "to_channel", "to_panel", "SourceError", "SourceImage",
    "read_source", "__version__",
]
