"""Writing panels and documents.

`save` writes a document again (§2.6 rule 6): panels the caller did not
change are written byte for byte; a panel the caller changed is written
again from its JSON, and its new carrier PNG goes into the SVG in place of
the old one; nothing else in the SVG changes. A panel whose assembly record
alone changes keeps every byte but that record (the assembly-only rewrite).

A tool that draws the figure itself builds the carrier PNGs with
`new_panel`, `rewrite_panel` and `assembly_only` (kept panels keep
`panel.carrier.png`), draws its SVG around them, and then records the
SVG's hash in the panels it wrote with `sign` (§6.5). Drawing the figure is
the tool's job, not this module's.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from datetime import datetime
import uuid
import zlib

import xml.etree.ElementTree as ET

import numpy as np

from . import _carrier, _check as C, _datauri, _embedded, _encode, _hashes, _json, _png, _splice, _svghash, _svgxml
from ._core import CHANNEL_IMAGE_KIND, CHANNEL_IMAGE_MEDIA
from .container import read_container
from .document import Document
from .notices import Kind, Notice
from .panel import FORMAT_URL, OMITTABLE, Panel, read_panel

_SVG_HASH_METHOD = "c14n2_without_panel_data"
_TOP = ("format", "schema_version", "schema_revision", "saved_at", "written_by", "core", "quantifications", "figure")


@dataclass(frozen=True)
class Tool:
    """The writer, recorded as `written_by` in each panel it writes (§3).
    `extension` is the name of its own extension (§8), the only one it may
    change: a panel written again carries every other extension as read."""

    name: str
    version: str
    build: str | None = None
    extension: str | None = None

    def record(self) -> dict:
        out = {"name": self.name, "version": self.version}
        if self.build is not None:
            out["build"] = self.build
        return out


@dataclass
class Content:
    """What a panel is written from.

    `json` is the panel to write: for a changed panel, usually
    `panel.to_json()` after the caller's edits. The writer sets `format`,
    the version, `saved_at` and `written_by`, builds `embedded`, and fills
    `figure` itself; of `figure`, only `crop` and `style` are read from
    `json`.

    `json["figure"]["style"]` is the style the figure was drawn with
    (§6.7): give it whenever you draw the figure again (its labels, not only
    the rendered image), with the values you drew with, or None for none.
    Left out, a changed panel whose rendered image is kept keeps the style
    it was read with, and a new rendered image has none. `panel.to_json()`
    holds the style as read, so a caller that draws again and keeps that
    JSON must replace it.

    `extensions` other than the writer's own (`Tool.extension`) are carried
    as read: changing one, or leaving it out, is refused, unless its name is
    in `removed_extensions`, the extensions the user chose to remove whole
    (§8).

    `rendered` is a rendered image the caller drew from this core (§6.2)
    over `json["figure"]["crop"]`, as `drawing.render()` draws it;
    `drawn_from` and `rendered_hash` are computed from it. A new panel needs one. When a changed panel has none,
    its previous rendered image is kept as it was, and so are `crop`,
    `rendered_hash` and `drawn_from` (§6.4: a changed core then shows the
    figure as older than the data).

    `invert_kept`, for a changed panel with no `rendered`: its previous
    rendered image is kept with its values inverted (the type's maximum −
    value), as §6.2 allows when the channel images cannot be had; its
    `rendered_hash` is computed again and `drawn_from` is kept.

    `source_channel_images`, `source_channel_pngs` and `source_metadata`
    are the payloads the JSON points to, beyond what a changed panel already
    holds: source channel images as pixels, or as source channel image PNGs
    (§5.3) kept byte for byte, and source metadata as (catalog entry,
    payload).

    A writer embeds the image of every source channel whose pixels it holds
    (§5.3), so every `pixel_hash` in the JSON needs its image: held by a
    changed panel, or given here. `pixels_not_held` names the `pixel_hash`
    values whose pixels the caller does not hold (their embedding was lost
    in the document it read, or their PNG would be too large, §1.5); they
    are written without their images. For a changed panel, those the panel
    as read had no usable image for count as not held without being named.
    Any other `pixel_hash` without its image is refused."""

    json: dict
    rendered: np.ndarray | None = None
    source_channel_images: list[np.ndarray] = field(default_factory=list)
    source_metadata: list[tuple[dict, bytes]] = field(default_factory=list)
    source_channel_pngs: list[bytes] = field(default_factory=list)
    invert_kept: bool = False
    removed_extensions: tuple[str, ...] = ()
    pixels_not_held: tuple[str, ...] = ()


@dataclass(frozen=True)
class WriteNote:
    """Something the writer did that the caller may want to pass on."""

    code: str
    message: str
    panel: int | None = None


class WriteError(Exception):
    """The document was not written. `notices` tells what reading the panel
    as it would have been written found wrong."""

    def __init__(self, message: str, panel: int | None = None, notices: list[Notice] | None = None):
        super().__init__(message)
        self.panel = panel
        self.notices = list(notices or [])


@dataclass
class Saved:
    svg: bytes
    notes: list[WriteNote] = field(default_factory=list)


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


# --- the assembly-only rewrite ---------------------------------------------------------------------


_ASSEMBLY_KEYS = ("id", "member", "members", "name", "omitted")


def _good_name(name) -> bool:
    if not C.is_str(name) or not name or "\r" in name:
        return False
    try:
        _json._check_string(name)
    except _json._Reject:
        return False
    return True


def _check_assembly(record, index: int) -> dict | None:
    if record is None:
        return None
    if (type(record) is not dict or not {"id", "member", "members"} <= set(record) <= set(_ASSEMBLY_KEYS)
            or not C.is_id(record["id"]) or not C.is_int(record["member"]) or not C.is_int(record["members"])
            or not 1 <= record["member"] <= record["members"]
            or ("name" in record and not _good_name(record["name"]))
            or ("omitted" in record and not _good_omitted(record["omitted"]))):
        raise WriteError("An assembly record is an object of 'id' (an ID), 'member' and 'members' "
                         "(integers, 1 ≤ member ≤ members), and optionally 'name' (a string, not empty, "
                         "without CR, lone surrogates or Unicode noncharacters) and 'omitted' (different parts of "
                         f"{', '.join(OMITTABLE)}, at least one).", index)
    return {key: record[key] for key in _ASSEMBLY_KEYS if key in record}


def _good_omitted(omitted) -> bool:
    return (type(omitted) is list and len(omitted) > 0 and all(type(v) is str and v in OMITTABLE for v in omitted)
            and len(set(omitted)) == len(omitted))


def _omitted_as_read(panel: Panel, record: dict | None) -> dict | None:
    """§1.7: an assembly-only rewrite draws nothing again, so the parts the
    set left out of the panel stay as read. A record without `omitted` gets
    the panel's; one with another refuses."""

    if record is None:
        return None
    read = (panel.assembly or {}).get("omitted")
    if "omitted" not in record:
        return {**record, "omitted": read} if read is not None else record
    if record["omitted"] != read:
        raise WriteError("The parts the set left out of the panel ('omitted') change only when the set is drawn "
                         "again; an assembly-only rewrite keeps them as read.", panel.index)
    return record


def _name_left_out(panel: Panel, record, notes: list[WriteNote] | None) -> None:
    """§1.7: a name is written as read unless the user changed it. One the
    caller's record leaves out is gone; say so."""

    name = (panel.assembly or {}).get("name")
    if notes is not None and name is not None and type(record) is dict and "name" not in record:
        notes.append(WriteNote("assembly.name.removed", f"The panel's name in its set ({name!r}) was left out of its "
                               "new assembly record, so it is no longer written.", panel.index))


def new_assembly_id() -> str:
    """A new, random assembly ID (§1.7: a UUID version 4)."""

    return str(uuid.uuid4())


def _replace_json_member(png: bytes, key: str, value) -> bytes:
    """The carrier PNG with one top-level member of its JSON replaced (None
    takes it out). Every other byte, and the iTXt's other fields and place,
    stay as they were."""

    (chunk,) = _carrier.find_keyword(_png.walk(png), _carrier.GELSVG_KEYWORD)
    fields, _ = _carrier.parse_itxt(chunk.data)
    text = _splice.replace_top_member(fields.text, key, value)
    body = zlib.compress(text, 9) if fields.compression_flag == 1 else text
    data = (fields.keyword + b"\0" + bytes([fields.compression_flag, fields.compression_method])
            + fields.language_tag + b"\0" + fields.translated_keyword + b"\0" + body)
    return png[: chunk.offset] + _encode.chunk(b"iTXt", data) + png[chunk.offset + 12 + chunk.length :]


def assembly_only(panel: Panel, record: dict | None, allow_loss: bool = False,
                  notes: list[WriteNote] | None = None) -> bytes:
    """The panel's carrier PNG with only the top-level `assembly` changed
    (None takes it out). A `name` read with the panel and left out of
    `record` is removed, with a note in `notes`: pass the name to keep it."""

    record = _check_assembly(record, panel.index)
    if not panel.readable or panel.newer_version or panel.schema_version != C.KNOWN_VERSION:
        raise WriteError("Only the assembly record of a readable panel of this version of the format can be "
                         "changed; this panel keeps its record, and so leaves the assembly.", panel.index)
    raw = panel.raw.get("assembly")
    if type(raw) is dict and set(raw) - set(_ASSEMBLY_KEYS) and not allow_loss:
        raise WriteError("The panel's assembly record has keys this writer does not know; changing it drops them. "
                         "Pass allow_loss=True to go ahead.", panel.index)
    if (type(raw) is dict and type(raw.get("omitted")) is list and set(map(str, raw["omitted"])) - set(OMITTABLE)
            and not allow_loss):
        raise WriteError("The panel's assembly record names parts this writer does not know in 'omitted'; changing "
                         "it drops them. Pass allow_loss=True to go ahead.", panel.index)
    record = _omitted_as_read(panel, record)
    if raw == record and ("assembly" in panel.raw) == (record is not None):
        return panel.carrier.png
    _name_left_out(panel, record, notes)
    return _replace_json_member(panel.carrier.png, "assembly", record)


# --- writing a panel ------------------------------------------------------------------------------


def _kept_image(panel: Panel) -> None:
    """Refuse to keep a rendered image the panel cannot be written with
    (§6.2, §2.6 rule 6)."""

    carrier = panel.carrier
    why = None
    if not carrier.rendered_usable or panel.rendered is None:
        why = "its rendered image cannot be used"
    elif any(panel.figure.get(k) is None for k in ("crop", "rendered_hash", "drawn_from")):
        why = "'figure' lacks a value it must have"
    elif panel.checks.get("rendered_hash") is None:
        why = "its rendered image cannot be checked against 'rendered_hash'"
    elif any(n.code in ("check.rendered_form", "figure.rendered_form") for n in panel.notices):
        why = "its rendered image's PNG form does not match the core it was drawn from"
    if why:
        raise WriteError(f"The panel cannot be written with its previous rendered image: {why}. "
                         "Draw it again and pass the pixels as Content.rendered.", panel.index)


@dataclass
class _Kept:
    """A rendered image kept as it was: its PNG, and the figure record that
    goes with it, and its pixels. `legacy` also drops an old MyWB carrier's
    data."""

    png: bytes
    walk: _png.Walk
    figure: dict
    legacy: bool = False
    pixels: np.ndarray | None = None


def _kept_image_png(kept: _Kept, itxt: bytes, gels: bytes) -> bytes:
    """The previous carrier PNG with a new JSON and new geLs chunks. Every
    other chunk keeps its bytes, so the SVG's hash input does not change
    (§6.5)."""

    png = kept.png
    data_types = (_png.GELS_TYPE, b"myWb") if kept.legacy else (_png.GELS_TYPE,)
    keywords = (_carrier.GELSVG_KEYWORD, _carrier.LEGACY_KEYWORD) if kept.legacy else (_carrier.GELSVG_KEYWORD,)
    out = [_png.PNG_SIGNATURE]
    for c in kept.walk.chunks:
        if c.type == b"IEND":
            break
        if c.runs_past_end or not c.crc_ok or c.type in data_types:
            continue
        if _carrier._keyword_of(c) in keywords:
            continue
        out.append(png[c.offset : c.offset + 12 + c.length])
        if c.type == b"IHDR":
            out.append(itxt)
    out += [gels, _encode.IEND]
    return b"".join(out)


def _with_embedded(core: dict, embedded: dict) -> dict:
    out = {}
    for key, value in core.items():
        out[key] = value
        if key == "sources":
            out["embedded"] = embedded
    if "embedded" not in out:
        out["embedded"] = embedded
    return out


def _problem(notice: Notice) -> bool:
    if notice.kind is Kind.CHECK:
        return notice.code in ("check.rendered_form", "check.crop.size")
    return notice.code != "metadata.unknown"  # carried over unread (§5.4)


def _channel_entry(pixels: np.ndarray) -> dict:
    png = _encode.channel_png(pixels)
    return {"dtype": "uint8" if pixels.dtype == np.uint8 else "uint16", "shape": list(pixels.shape),
            "byte_length": len(png), "payload_hash": _hashes.sha256(png), "payload": png}


def _build(content: Content, tool: Tool, saved_at: str | None, notes: list[WriteNote], *,
           index: int | None, element, images: dict, metadata: dict, kept: _Kept | None,
           decoded: dict | None = None, lost: frozenset = frozenset()) -> bytes:
    """Write the panel's JSON and carrier PNG, and read them back. `images`
    and `metadata` are the payloads already held, by key; `kept` is the
    rendered image kept when no new one is given; `decoded` holds the pixels
    of payloads already decoded, by the SHA-256 (hex) of their bytes, so
    reading back need not decode them again; `lost` holds the pixel hashes a
    changed panel had no usable image for, written without one (§5.3)."""

    data = copy.deepcopy(content.json)
    if type(data) is not dict or type(data.get("core")) is not dict:
        raise WriteError("Content.json must be an object with a 'core' object.", index)
    core = data["core"]
    core.pop("embedded", None)

    images = dict(images)
    decoded = dict(decoded or {})
    for pixels in content.source_channel_images:
        if pixels.dtype not in (np.uint8, np.uint16) or pixels.ndim != 2 or 0 in pixels.shape:
            raise WriteError("A source channel image is a (h, w) image of uint8 or uint16.", index)
        key = _hashes.pixel_hash(pixels)
        if key not in images:  # a payload already held keeps its bytes
            images[key] = _channel_entry(pixels)
            decoded[images[key]["payload_hash"][len("sha256:"):]] = pixels
    for png in content.source_channel_pngs:
        pixels, why = _embedded.decode_channel_png(png)
        if pixels is None:
            raise WriteError(f"A source channel image PNG cannot be embedded: {why}.", index)
        key = _hashes.pixel_hash(pixels)
        if key not in images:
            images[key] = {"dtype": "uint8" if pixels.dtype == np.uint8 else "uint16", "shape": list(pixels.shape),
                           "byte_length": len(png), "payload_hash": _hashes.sha256(png), "payload": png}
            decoded[images[key]["payload_hash"][len("sha256:"):]] = pixels
    metadata = dict(metadata)
    for entry, payload in content.source_metadata:
        metadata[_hashes.sha256(_json.canonical(entry))] = (entry, payload)

    image_catalog, metadata_catalog = {}, {}
    not_held = lost | set(content.pixels_not_held)
    unheld = []
    for source in core.get("sources") if type(core.get("sources")) is list else ():
        if type(source) is not dict:
            continue
        for channel in source.get("source_channels") if type(source.get("source_channels")) is list else ():
            key = channel.get("pixel_hash") if type(channel) is dict else None
            if type(key) is str and key not in images and key not in not_held:
                unheld.append(f"'{channel.get('name')}' of the source '{source.get('id')}'")
            if key in images and key not in image_catalog:
                e = images[key]
                image_catalog[key] = {"kind": CHANNEL_IMAGE_KIND, "media_type": CHANNEL_IMAGE_MEDIA, "dtype": e["dtype"],
                                      "shape": e["shape"], "byte_length": e["byte_length"], "payload_hash": e["payload_hash"]}
        key = source.get("source_metadata")
        if key in metadata and key not in metadata_catalog:
            metadata_catalog[key] = metadata[key][0]
    if unheld:
        raise WriteError(f"The image of the source channel {', '.join(unheld)} is not given: a writer embeds the image "
                         "of every source channel whose pixels it holds (§5.3). Name its pixel_hash in "
                         "Content.pixels_not_held only if its pixels are not held.", index)
    embedded = {}
    if image_catalog:
        embedded["source_channel_images"] = image_catalog
    if metadata_catalog:
        embedded["source_metadata"] = metadata_catalog
    if embedded:
        core = _with_embedded(core, embedded)

    # The figure record.
    redrawn = content.rendered
    if content.rendered is None:
        figure = copy.deepcopy(kept.figure)
        if content.invert_kept:
            # §6.2: the kept picture's values turned over, its hash taken again.
            redrawn = np.iinfo(kept.pixels.dtype).max - kept.pixels
            figure["rendered_hash"] = _hashes.rendered_hash(redrawn)
    else:
        pixels = content.rendered
        if (pixels.dtype not in (np.uint8, np.uint16) or pixels.ndim not in (2, 3)
                or (pixels.ndim == 3 and pixels.shape[2] != 3) or 0 in pixels.shape):
            raise WriteError("Content.rendered must be a grey (h, w) or RGB (h, w, 3) image of uint8 or uint16.", index)
        crop = data["figure"].get("crop") if type(data.get("figure")) is dict else None
        figure = {"crop": crop, "rendered_hash": _hashes.rendered_hash(pixels), "drawn_from": _hashes.core_hash(core)}
    # §6.7: the style the figure was drawn with, as the caller gives it.
    if type(data.get("figure")) is dict and "style" in data["figure"]:
        figure.pop("style", None)
        if data["figure"]["style"]:
            figure["style"] = data["figure"]["style"]

    # Quantifications measured on another core are dropped (§7.4).
    quant_hash = _hashes.quant_core_hash(core)
    quants = data.get("quantifications")
    if type(quants) is list:
        kept_quants = []
        for i, q in enumerate(quants):
            if type(q) is dict and q.get("computed_on") != quant_hash:
                notes.append(WriteNote("quantification.stale", f"The quantification {i} was measured on another core "
                                       "and was left out (§7.4).", index))
                continue
            kept_quants.append(q)
        quants = kept_quants or None

    out = {"format": FORMAT_URL, "schema_version": C.KNOWN_VERSION, "schema_revision": C.KNOWN_REVISION,
           "saved_at": saved_at or _now(), "written_by": tool.record(), "core": core}
    if quants is not None:
        out["quantifications"] = quants  # anything but a list is left for the check below to refuse
    out["figure"] = figure
    for key, value in data.items():
        if key not in _TOP:
            out[key] = value
    try:
        # Extensions and a method's parameters keep how their numbers were written (`2.0` stays `2.0`; §7.1, §8).
        text = _json.dumps(out, keep_floats=(("extensions",), ("quantifications", "*", "method", "parameters")))
    except (TypeError, ValueError, UnicodeEncodeError) as exc:
        raise WriteError(f"The panel's JSON cannot be written: {exc}.", index) from None

    itxt = _encode.itxt(text)
    gels = _encode.gels_chunks([images[k]["payload"] for k in image_catalog],
                               [metadata[k][1] for k in metadata_catalog])
    if redrawn is None:
        png = _kept_image_png(kept, itxt, gels)
    else:
        header, stream = _encode.encode_image(redrawn)
        png = _png.PNG_SIGNATURE + header + itxt + _encode.idat_chunks(stream) + gels + _encode.IEND

    # Read it back: what would be written must read without a problem.
    walk = _png.walk(png)
    carrier = _carrier.assess(png, walk, _carrier.find_keyword(walk, _carrier.GELSVG_KEYWORD))
    check = read_panel(index if index is not None else 0, element, carrier, decoded=decoded)
    problems = [n for n in check.notices if _problem(n)]
    if problems:
        raise WriteError("The panel would not be written as the format requires: "
                         + "; ".join(n.message for n in problems[:3]) + ("…" if len(problems) > 3 else ""),
                         index, problems)
    return png


def _same(a, b) -> bool:
    """Equal as JSON values, number notation included (§2.2: 2 and 2.0
    differ)."""

    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(_same(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(_same(x, y) for x, y in zip(a, b))
    return a == b


def _check_extensions(panel: Panel, content: Content, tool: Tool, notes: list[WriteNote]) -> None:
    """§8: only the owner writes an extension. Every other one read with the
    panel is carried untouched, or removed whole when the user chose to."""

    data = content.json if type(content.json) is dict else {}
    given = data.get("extensions") if type(data.get("extensions")) is dict else {}
    read_ones = {name: record["value"] for name, record in panel.extensions.items()}
    index = panel.index
    for name, value in read_ones.items():
        if name == tool.extension:
            continue
        if name in content.removed_extensions:
            if name in given:
                raise WriteError(f"The extension {name!r} is to be removed, but Content.json still holds it.", index)
            notes.append(WriteNote("extension.removed", f"The extension {name!r} was removed whole, as the user "
                                   "chose (§8).", index))
        elif name not in given:
            raise WriteError(f"The extension {name!r} belongs to another tool and is carried over as read (§8); "
                             "to remove it whole at the user's choice, name it in Content.removed_extensions.", index)
        elif not _same(given[name], value):
            raise WriteError(f"The extension {name!r} belongs to another tool; only its owner changes it (§8).", index)
    for name in given:
        if name != tool.extension and name not in read_ones:
            raise WriteError(f"The extension {name!r} is not this writer's own (Tool.extension) and was not in the "
                             "panel; only its owner writes it (§8).", index)


def rewrite_panel(panel: Panel, content: Content, tool: Tool, *, saved_at: str | None = None,
                  allow_loss: bool = False, notes: list[WriteNote] | None = None) -> bytes:
    """The new carrier PNG of a panel the caller changed. Raises WriteError
    when the panel cannot be written as the format requires."""

    notes = notes if notes is not None else []
    index = panel.index
    if not panel.readable or panel.newer_version:
        raise WriteError("The panel was not read (unreadable, or of a newer version of the format), so it can only "
                         "be kept byte for byte.", index)
    if panel.newer_revision and not allow_loss:
        raise WriteError("The panel is of a newer revision; writing it again drops what that revision added. "
                         "Pass allow_loss=True to go ahead.", index)
    if content.rendered is None:
        _kept_image(panel)
        if content.invert_kept and panel.checks.get("rendered_hash") is not True:
            raise WriteError("The panel's rendered image does not match its 'rendered_hash', so its pixels must not "
                             "be changed (§6.2).", index)
    elif content.invert_kept:
        raise WriteError("Content.invert_kept keeps the previous rendered image; it cannot go with a new one.", index)
    _check_extensions(panel, content, tool, notes)
    if type(content.json) is dict:
        _name_left_out(panel, content.json.get("assembly"), notes)
    view = panel.core
    images = {k: e for k, e in view.source_channel_images.items() if e.get("payload") is not None}
    metadata = {k: (r["entry"], r["payload"]) for k, r in view.source_metadata.items() if r.get("payload") is not None}
    decoded = {e["payload_hash"][len("sha256:"):]: panel.source_channel_images[k] for k, e in images.items()
               if k in panel.source_channel_images and e["payload_hash"].startswith("sha256:")}
    # Pixel hashes the panel as read had no usable image for: their embedding was lost (§5.3).
    lost = frozenset(c["pixel_hash"] for s in view.sources or () if type(s) is dict
                     for c in s.get("source_channels") or () if type(c) is dict and type(c.get("pixel_hash")) is str
                     and c["pixel_hash"] not in images)
    png = _build(content, tool, saved_at, notes, index=index, element=panel.element, images=images,
                 metadata=metadata, decoded=decoded, lost=lost,
                 kept=_Kept(panel.carrier.png, panel.carrier.walk,
                            {k: panel.figure[k] for k in ("crop", "rendered_hash", "drawn_from", "style")
                             if k != "style" or panel.figure.get("style") is not None},
                            pixels=panel.rendered))
    if panel.figure.get("svg_hash") is not None:
        notes.append(WriteNote("svg_hash.removed", "The panel's svg_hash was left out: it recorded the SVG as an "
                               "earlier writer wrote it (§6.5).", index))
    return png


def new_panel(content: Content, tool: Tool, *, saved_at: str | None = None,
              notes: list[WriteNote] | None = None) -> bytes:
    """The carrier PNG of a new panel. Raises WriteError when it cannot be
    written as the format requires."""

    if content.rendered is None:
        raise WriteError("A new panel needs its rendered image (Content.rendered).")
    element = _svgxml.Element(_svgxml.SVG_NS, "image", {}, None)
    return _build(content, tool, saved_at, notes if notes is not None else [], index=None, element=element,
                  images={}, metadata={}, kept=None)


def image_element(png: bytes, x: float = 0, y: float = 0, scale: float = 1) -> str:
    """An SVG `image` element drawing a carrier PNG at (x, y), each pixel
    `scale` units wide (§1.2, §1.6)."""

    ihdr = _png.Ihdr.parse(_png.walk(png).chunks[0].data)
    n = _json.number
    return (f'<image x="{n(x)}" y="{n(y)}" width="{n(ihdr.width * scale)}" height="{n(ihdr.height * scale)}" '
            f'preserveAspectRatio="xMidYMid meet" href="{_splice.png_data_uri(png).decode("ascii")}"/>')


def replace_element(svg: bytes, element: _svgxml.Element, data: bytes) -> bytes:
    """The SVG with an element read from it (`drawing_of`, for example)
    replaced by `data`; every other byte stays as it was."""

    start, end = _splice.element_span(svg, element)
    return _splice.apply(svg, [(start, end, data)])


def set_attributes(svg: bytes, element: _svgxml.Element, values: dict[str, str]) -> bytes:
    """The SVG with attributes of an element read from it set to `values`
    (the root's `width`, `height` and `viewBox`, for example); every other
    byte stays as it was."""

    return _splice.set_attributes(svg, element, values)


def sign(svg: bytes, pngs) -> Saved:
    """Record the SVG's hash (§6.5) in the panels whose carrier PNG is one
    of `pngs`: the panels this writer wrote, in an SVG it drew itself. The
    hash's input leaves the panels' JSON out, so recording it does not
    change it. When the input cannot be made, nothing is recorded."""

    targets = set(pngs)
    try:
        value = _svghash.svg_hash(svg)
    except (_svghash.Unavailable, ET.ParseError):
        return Saved(svg, [WriteNote("svg_hash.unavailable", "The SVG's hash could not be computed (§6.5), so it "
                                     "was not recorded.")])
    container = read_container(svg)
    replacements, found = [], set()
    for slot in container.panels:
        png = slot.carrier.png
        if png not in targets:
            continue
        found.add(png)
        figure = _json.parse(slot.carrier.json_text)["figure"]
        figure["svg_hash"], figure["svg_hash_method"] = value, _SVG_HASH_METHOD
        replacements.append((slot.element, _replace_json_member(png, "figure", figure)))
    if found != targets:
        raise WriteError(f"{len(targets - found)} of the PNGs to sign are not panels of this SVG.")
    return Saved(_splice.replace_hrefs(svg, replacements))


# --- the document --------------------------------------------------------------------------------


def save(document: Document, tool: Tool, *, rewrite: dict[int, Content] | None = None,
         assembly: dict[int, dict | None] | None = None, allow_loss: bool = False,
         saved_at: str | None = None) -> Saved:
    """Write the document again. `rewrite` maps panel indexes to the panels
    the caller changed; `assembly` maps indexes of panels kept byte for
    byte to their new assembly record (None leaves the assembly). Every
    other panel, and every other byte of the SVG, is written as read.

    Raises WriteError, writing nothing, when a panel cannot be written as
    asked."""

    rewrite = rewrite or {}
    assembly = assembly or {}
    if not document.is_document:
        raise WriteError("This file is not a GelSVG document.")
    both = set(rewrite) & set(assembly)
    if both:
        raise WriteError("A rewritten panel carries its assembly record in its JSON; it cannot also be given one "
                         f"in 'assembly' (panels {sorted(both)}).")
    for index in [*rewrite, *assembly]:
        if not 0 <= index < len(document.panels):
            raise WriteError(f"There is no panel {index}.")

    notes: list[WriteNote] = []
    stamp = saved_at or _now()
    pngs: dict[int, bytes] = {}
    for index, change in sorted(rewrite.items()):
        pngs[index] = rewrite_panel(document.panels[index], change, tool, saved_at=stamp,
                                    allow_loss=allow_loss, notes=notes)
    for index, record in sorted(assembly.items()):
        png = assembly_only(document.panels[index], record, allow_loss=allow_loss, notes=notes)
        if png is not document.panels[index].carrier.png:
            pngs[index] = png
    if not pngs:
        return Saved(document.svg, notes)

    panels = document.panels
    svg = _splice.replace_hrefs(document.svg, [(panels[i].element, png) for i, png in pngs.items()])
    tree = _svgxml.parse(svg)
    for index, png in pngs.items():
        element = tree.elements[panels[index].element.order]
        if _datauri.decode_png_data_uri(_datauri.image_href(element.attributes) or "") != png:
            raise WriteError("The new PNG could not be put into the SVG.", index)
    return Saved(svg, notes)
